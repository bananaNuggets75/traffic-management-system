﻿using Polgo_Constructions_Projects.Data;
using Polgo_Constructions_Projects.Models;
using Microsoft.EntityFrameworkCore;

namespace Polgo_Constructions_Projects.Services
{
    public class MaterialsService: IMaterialsService
    {
        private readonly DataContext _context;
        public MaterialsService(DataContext context)
        {
            _context = context;
        }

        public async Task AddMaterialsAsync(Materials materials)
        {
            _context.Materials.Add(materials);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteMaterialsAsync(int id)
        {
            var material = await _context.Materials.FindAsync(id);
            if (material != null)
            {
                _context.Materials.Remove(material);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<List<Materials>> GetAllMaterialsAsync()
        {
            var result = await _context.Materials.ToListAsync();
            return result;
        }

        public async Task<Materials> GetMaterialsByIdAsync(int id)
        {
            var material = await _context.Materials.FindAsync(id);
            return material;
        }

        public async Task UpdateMaterialsAsync(Materials materials, int id)
        {
            var dbMaterial = await _context.Materials.FindAsync(id);
            if (materials != null)
            {
                dbMaterial.materialName = materials.materialName;
                dbMaterial.description = materials.description;
                dbMaterial.length = materials.length;
                dbMaterial.price = materials.price;
                await _context.SaveChangesAsync();
            }
        }
    }
}
