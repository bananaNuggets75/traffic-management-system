﻿using System.Threading.Tasks;
using Polgo_Constructions_Projects.Models;

namespace Polgo_Constructions_Projects.Services
{
    public interface IMaterialsService
    {
        Task<List<Materials>> GetAllMaterialsAsync();
        Task<Materials> GetMaterialsByIdAsync(int id);
        Task AddMaterialsAsync(Materials materials);
        Task UpdateMaterialsAsync(Materials materials, int id);
        Task DeleteMaterialsAsync(int id);
    }
}
