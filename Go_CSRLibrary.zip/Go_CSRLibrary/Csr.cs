﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Diagnostics.CodeAnalysis;

namespace Go_CSRLibrary
{
    public class Csr
    {
        public string name { get; set; }
        public string company { get; set; }
        public int age { get; set; }
        public double averageTime;
        public string[] array;
        public string callMinutes {  get; set; }

        public Csr()
        {
            this.name = "";
            this.company = "";
            this.age = 0;
            this.callMinutes = "";
            averageTime = 0;
        }

        public Csr(string name, string company, int age, string callMinutes)
        {
            this.name = name;
            this.company = company;
            this.age = age;
            this.callMinutes = callMinutes;
        }

        public string getName()
        {
            return this.name;
        }

        public string getCompany()
        {
            return this.company;
        }

        public int getAge()
        {
            return this.age;
        }

        public double getAverageTime()
        {

            double sum = 0;
            string pattern = @"[,; ]+";

            string[] array = Regex.Split(this.callMinutes, pattern);

            for (int i = 0; i < array.Length; i++) 
            {
                string value = array[i].Trim();
                if (!string.IsNullOrEmpty(value))
                {
                    sum += Convert.ToDouble(value);
                }
            }

            this.averageTime = sum/4;
            return this.averageTime;
        }


        public string getCallMinutes()
        {
            return this.callMinutes;
        }

        public string calculateMostEfficient(Csr csr2, Csr csr3)
        {

            double[] times = { this.getAverageTime(), csr2.getAverageTime(), csr3.getAverageTime() };
            double most = times.Min();
            

            if (most == this.getAverageTime())
            {
                return "The most efficient is " + this.getName();
            }
            else if(most == csr2.getAverageTime())
            {
                return "The most efficient is " + csr2.getName();
            }
            else if (most == csr3.getAverageTime())
            {
                return "The most efficient is " + csr3.getName();
            }
            else
            {
                return "";
            }
        }

        public string calculateLeastEfficient(Csr csr2, Csr csr3)
        {

            double[] times = { this.getAverageTime(), csr2.getAverageTime(), csr3.getAverageTime() };
            double least = times.Max();


            if (least == this.getAverageTime())
            {
                return "The least efficient is " + this.getName();
            }
            else if (least == csr2.getAverageTime())
            {
                return "The least efficient is " + csr2.getName();
            }
            else if (least == csr3.getAverageTime())
            {
                return "The least efficient is " + csr3.getName();
            }
            else
            {
                return "";
            }
        }


    }   
}
